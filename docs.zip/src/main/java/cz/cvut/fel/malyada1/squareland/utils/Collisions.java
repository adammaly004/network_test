package cz.cvut.fel.malyada1.squareland.utils;

import static cz.cvut.fel.malyada1.squareland.utils.Constants.*;

/**
 * The Collisions class is responsible for handling collision detection between game entities and tiles.
 * It checks if a given entity is colliding with a tile based on its position and the map layout.
 */
public class Collisions
{
    private int[][] mapArray;

    /**
     * Sets the map for collision detection
     * @param mapArray the map to set
     */
    public void setMap(int[][] mapArray) {
        this.mapArray = mapArray;
    }

    /**
     * Checks if the entity is colliding with a tile based on its position and type
     * @param x the x-coordinate of the entity
     * @param y the y-coordinate of the entity
     * @param entity the type of entity (e.g., "player", "enemy")
     * @return true if colliding, false otherwise
     */
    public boolean isCollidingWithTile(double x, double y, String entity) {
        int row = (int) (y / TILE_SIZE);
        int col = (int) (x / TILE_SIZE);

        if (row < 0 || row >= mapArray.length || col < 0 || col >= mapArray[0].length) {
            return false;
        }

        int tileValue = mapArray[row][col];
        if (entity.equals("player")) {
            return tileValue == 1 || tileValue == 2;
        } else {
            return tileValue == 2;
        }

    }
}
