package cz.cvut.fel.malyada1.squareland.model;

import cz.cvut.fel.malyada1.squareland.model.item.GameItem;
import cz.cvut.fel.malyada1.squareland.model.map.Map;
import cz.cvut.fel.malyada1.squareland.model.player.PlayerModel;
import cz.cvut.fel.malyada1.squareland.model.projectile.Bullet;
import cz.cvut.fel.malyada1.squareland.model.projectile.FireBall;
import cz.cvut.fel.malyada1.squareland.model.projectile.GameCircle;
import cz.cvut.fel.malyada1.squareland.utils.ItemSpawner;
import javafx.scene.paint.Color;
import javafx.stage.FileChooser;
import cz.cvut.fel.malyada1.squareland.utils.Collisions;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Logger;

import static cz.cvut.fel.malyada1.squareland.utils.Constants.*;

/**
 * The Game class represents the game state, including players, map, and collisions.
 * It initializes the game components and provides methods to manage the game state.
 */
public class Game {
    private final PlayerModel player1;
    private final PlayerModel player2;

    private final Map map;
    private String filePath = "MAP.txt";

    private final Collisions collision;
    private final ItemSpawner itemSpawner;

    private final List<GameItem> items;
    private final List<GameCircle> fireBalls;

    private int itemTimer = 0;
    private int fireBallTimer = 0;

    private boolean isGameOver;
    private int winner;
    private boolean isPaused;

    private long elapsedTime; // Time in seconds
    private Thread stopwatchThread;
    private boolean isStopwatchRunning;

    private Logger logger = Logger.getLogger(Game.class.getName());

    /**
     * Constructor for the Game class.
     * Initializes the map, players, collisions, and item spawner.
     */
    public Game() {
        map = new Map(MAP_PATH + filePath);
        collision = new Collisions();
        collision.setMap(map.getMapArray());
        player1 = new PlayerModel(0, 0, TILE_SIZE, TILE_SIZE, "player1", Color.AQUA, collision);
        player2 = new PlayerModel(WIDTH-TILE_SIZE, HEIGHT-TILE_SIZE, TILE_SIZE, TILE_SIZE, "player2", Color.BLUEVIOLET, collision);
        itemSpawner = new ItemSpawner(map.getMapArray());

        items = new ArrayList<>();
        fireBalls = new ArrayList<>();

        isGameOver = false;
        winner = 0;
        isPaused = false;
    }

    /**
     * Checks if the game is over by checking the health of both players.
     * If one player's health is less than or equal to 0, the game is over and the other player is declared the winner.
     */
    private void checkGameOver() {
        if (player1.getHealth() <= 0) {
            isGameOver = true;
            winner = 2;
        } else if (player2.getHealth() <= 0) {
            isGameOver = true;
            winner = 1;
        }
    }

    /**
     * Handles the timer for spawning items.
     * If the timer exceeds a certain threshold, it spawns an item and resets the timer.
     * The spawned item is added to the list of items.
     */
    private void itemSpawnerTimer(){
        if (itemTimer > ITEM_SPAWN_RATE) {
            GameItem i = itemSpawner.spawnItems();
            if (i != null) {
                items.add(i);
            }
            itemTimer = 0;
        }
        itemTimer++;
    }

    /**
     * Handles the timer for spawning fireballs.
     * If the timer exceeds a certain threshold, it spawns a fireball and resets the timer.
     * The spawned fireball is added to the list of fireballs.
     */
    private void fireBallSpawnerTimer(){
        if (fireBallTimer > FIREBALL_SPAWN_RATE) {
            FireBall i = itemSpawner.spawnFireBall();
            fireBalls.add(i);
            fireBallTimer = 0;
        }else{
            for (GameCircle fireBall : fireBalls) {
                if (fireBall instanceof FireBall f) {
                    f.initFireBall();
                }

            }
        }
        if(fireBalls.size() > 3){
            fireBalls.removeFirst();
        }
        fireBallTimer++;
    }

    /**
     * Updates the position of bullets and checks for collisions.
     * If a bullet collides with a tile or goes out of bounds, it is removed from the list.
     * @param bullets The list of bullets to update.
     */
    private void updateBullets(List<GameCircle> bullets){
        List<Bullet> bulletsToRemove = new ArrayList<>();
        for (GameCircle bullet : bullets) {
            Bullet b = (Bullet) bullet;
            b.move();
            if (collision.isCollidingWithTile(bullet.getCenterX(), bullet.getCenterY(), "bullet") || bullet.getCenterY() < 0 || bullet.getCenterY() > HEIGHT || bullet.getCenterX() < 0 || bullet.getCenterX() > WIDTH) {
                bulletsToRemove.add(b);
            }
        }
        bullets.removeAll(bulletsToRemove);
    }

    /**
     * Updates the players' positions and checks for collisions with items, bullets, and fireballs.
     * Each player checks for collisions with the other player's bullets and fireballs.
     */
    private void updatePlayers(){
        player1.borderCollision();
        player1.rectangleCollision(items);
        player1.circleCollision(player2.getBullets());
        player1.circleCollision(fireBalls);
        player1.tileCollision();

        player2.borderCollision();
        player2.rectangleCollision(items);
        player2.circleCollision(player1.getBullets());
        player2.circleCollision(fireBalls);
        player2.tileCollision();

    }

    /**
     * Sets the map file path to a new file selected by the user.
     * Opens a file chooser dialog to select a text file.
     * If no file is selected, it defaults to the original map file.
     */
    public void chooseMapFile() {
        FileChooser fileChooser = new FileChooser();
        fileChooser.setInitialDirectory(new File(MAP_PATH));
        fileChooser.setTitle("Open Resource File");
        fileChooser.getExtensionFilters().add(new FileChooser.ExtensionFilter("Text Files", "*.txt"));

        File selectedFile = fileChooser.showOpenDialog(null);
        if (selectedFile != null) {
            filePath = selectedFile.getPath();
            logger.info("Selected file: " + filePath);

        } else {
            System.out.println("No File Selected");
            filePath = MAP_PATH + "MAP.txt";
            logger.info("No file selected, using default map.");
        }

        // Update the map and collision with the new file path
        map.setMapArray(filePath);
        collision.setMap(map.getMapArray());
        itemSpawner.setMap(map.getMapArray());
    }

    /**
     * Resets the game state by clearing items and fireballs, and resetting players.
     */
    public void reset() {
        items.clear();
        fireBalls.clear();
        player1.reset();
        player2.reset();
        isGameOver = false;
        winner = 0;
    }

    /**
     * Updates the game state by updating players, bullets, and timers for item and fireball spawners.
     */
    public void update(){
        this.updatePlayers();
        this.updateBullets(player1.getBullets());
        this.updateBullets(player2.getBullets());
        this.fireBallSpawnerTimer();
        this.itemSpawnerTimer();
        this.checkGameOver();
    }

    /**
     * Starts the stopwatch thread to track elapsed time.
     * The stopwatch runs in a separate thread and updates the elapsed time every second.
     */
    public void startStopwatch() {
        if (stopwatchThread == null || !isStopwatchRunning) {
            isStopwatchRunning = true;
            stopwatchThread = new Thread(() -> {
                while (isStopwatchRunning) {
                    try {
                        Thread.sleep(1000);
                        elapsedTime++;
                    } catch (InterruptedException e) {
                        Thread.currentThread().interrupt();
                    }
                }
            });
            stopwatchThread.start();
            logger.info("Starting Stopwatch");
        }
    }

    /**
     * Stops the stopwatch thread.
     * The stopwatch thread is interrupted and the running state is set to false.
     */
    public void stopStopwatch() {
        isStopwatchRunning = false;
        if (stopwatchThread != null) {
            stopwatchThread.interrupt();
            logger.info("Stopwatch thread interrupted");
        }
    }

    /**
     * Resets the stopwatch by stopping it and setting the elapsed time to 0.
     */
    public void resetStopwatch() {
        stopStopwatch();
        elapsedTime = 0;
        logger.info("Stopwatch reset");
    }

    /**
     * Returns the elapsed time in a formatted string (HH:MM:SS).
     * @return The formatted elapsed time.
     */
    public String getStopWatchTime(){
        long seconds = elapsedTime % 60;
        long minutes = (elapsedTime / 60) % 60;
        long hours = (elapsedTime / 3600);
        return String.format("%02d:%02d:%02d", hours, minutes, seconds);
    }

    public long getElapsedTime() {
        return elapsedTime;
    }

    public PlayerModel getPlayer1() {
        return player1;
    }
    public PlayerModel getPlayer2() {
        return player2;
    }

    public List<GameItem> getItems() {
        return items;
    }
    public List<GameCircle> getFireBalls() {
        return fireBalls;
    }

    public Map getMap() {
        return map;
    }

    public String getFilePath() {return filePath;}

    public boolean isGameOver() {
        return isGameOver;
    }
    public int getWinner() {
        return winner;
    }
    public boolean getIsPaused() {
        return isPaused;
    }
    public void setIsPaused(boolean paused) {
        isPaused = paused;
    }
}