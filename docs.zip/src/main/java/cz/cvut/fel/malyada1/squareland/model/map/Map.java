package cz.cvut.fel.malyada1.squareland.model.map;

import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;

import static cz.cvut.fel.malyada1.squareland.utils.Constants.*;
import static cz.cvut.fel.malyada1.squareland.utils.MapLoader.loadMap;

/**
 * The Map class represents the game map.
 * It is responsible for loading the map from a file and drawing it on the screen.
 */
public class Map {

    private int[][] mapArray;

    /**
     * The constructor initializes the map from a file.
     * @param filePath the path to the map file
     */
    public Map(String filePath){
        initMap(filePath);
    }

    /**
     * Loads the map from a file and initializes the mapArray
     * @param filePath the path to the map file
     */
    private void initMap(String filePath) {
        int[][] loadedMap = loadMap(filePath);
        if(loadedMap != null) {
            this.mapArray = loadedMap;
        }
    }

    /**
     * Sets the color of the tile based on its value in the mapArray
     * @param row is the row of the tiles
     * @param col is the column of the tiles
     * @param existingTile is the Rectangle representing the tile
     */
    public void setColors(int row, int col, Rectangle existingTile) {
        switch (mapArray[row][col]) {
            case BLUE:
                existingTile.setFill(Color.BLUE);
                break;
            case GRAY:
                existingTile.setFill(Color.GRAY);
                break;
            default:
                existingTile.setFill(Color.GREEN);
                break;
        }
    }

    /**
     * Increments the tile value (which will change color) at the given row and column
     * @param row is the row of the tiles
     * @param col is the column of the tiles
     */
    public void incrementTile(int row, int col) {
        mapArray[row][col] = (mapArray[row][col] + 1) % 3;
    }

    /**
     * Sets the tile value (which will change color) at the given row and column
     * @param row is the row of the tiles
     * @param col is the column of the tiles
     * @param value is the value to set the tile
     */
    public void setTile(int row, int col, int value) {
        mapArray[row][col] = value;
    }

    /**
     * Getter for the map array
     * @return the map array
     */
    public int[][] getMapArray() {
        return mapArray;
    }

    /**
     * Sets the map array from a file path
     * @param filePath the path to the map file
     */
    public void setMapArray(String filePath) {
        initMap(filePath);
    }
}
