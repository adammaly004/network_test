package cz.cvut.fel.malyada1.squareland.utils;


/**
 * The Constants class contains various constants used throughout the game.
 * It includes window dimensions, tile size, player controls, and file paths.
 */
public class Constants {

    // Setting the width and height of the game window
    public static final int WIDTH = 800;
    public static final int HEIGHT = 600;
    public static final int TILE_SIZE = 20;

    // Game Colors on the map
    public static final int BLUE = 1;
    public static final int GRAY = 2;

    // Timers for game events
    public static final int FIREBALL_SPAWN_RATE = 100;
    public static final int ITEM_SPAWN_RATE = 100;

    // Map files path
    public static final String MAP_PATH = "./src/main/resources/cz/cvut/fel/malyada1/squareland/";
}

