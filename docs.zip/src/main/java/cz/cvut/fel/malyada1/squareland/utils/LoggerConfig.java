package cz.cvut.fel.malyada1.squareland.utils;

import java.util.logging.Level;
import java.util.logging.Logger;

public class LoggerConfig {

    private static boolean loggingEnabled = true;

    private static void enableLogging() {
        Logger rootLogger = Logger.getLogger("");
        rootLogger.setLevel(Level.ALL);
        for (var handler : rootLogger.getHandlers()) {
            handler.setLevel(Level.ALL);
        }
        loggingEnabled = true;
        System.out.println("Logging ENABLED");
    }

    private static void disableLogging() {
        Logger rootLogger = Logger.getLogger("");
        rootLogger.setLevel(Level.OFF);
        for (var handler : rootLogger.getHandlers()) {
            handler.setLevel(Level.OFF);
        }
        loggingEnabled = false;
        System.out.println("Logging DISABLED");
    }

    public static void toggleLogging() {
        if (loggingEnabled) {
            disableLogging();
        } else {
            enableLogging();
        }
    }

    public static boolean isLoggingEnabled() {
        return loggingEnabled;
    }
}