package cz.cvut.fel.malyada1.squareland;


import javafx.application.Application;
import javafx.stage.Stage;

import cz.cvut.fel.malyada1.squareland.controller.SceneController;

/**
 * The Main class is the entry point of the JavaFX application.
 * It initializes the primary stage and sets up the scene controller.
 */
public class Main extends Application {

    /**
     * The start method is called when the application is launched.
     * It initializes the primary stage and sets up the scene controller.
     * @param primaryStage is the main stage of the application
     */
    @Override
    public void start(Stage primaryStage) {
        SceneController sceneController = new SceneController(primaryStage);
        sceneController.showMenu();
        primaryStage.show();

        // On close request, stop the stopwatch thread
        primaryStage.setOnCloseRequest(_ -> {
            sceneController.getGame().stopStopwatch();
        });
    }

    /**
     * The main method is the entry point of the application.
     * It launches the JavaFX application.
     * @param args command line arguments
     */
    public static void main(String[] args) {
        launch(args);
    }
}