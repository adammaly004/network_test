package cz.cvut.fel.malyada1.squareland.model.map;

import static cz.cvut.fel.malyada1.squareland.utils.Constants.*;

/**
 * The MapEditor class is responsible for creating and managing the map used in the game.
 * It initializes a blank map from a specified file path.
 */
public class MapEditor {
    private final Map map;
    String path = MAP_PATH + "BLANKMAP.txt";
    /**
     * Constructor for the MapEditor class.
     * It initializes the map with a blank map from the specified file path.
     */
    public MapEditor() {
        map = new Map(path);
    }

    /**
     * Getter for the map
     * @return the map
     */
    public Map getMap() {
        return map;
    }

}
