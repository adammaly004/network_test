package cz.cvut.fel.malyada1.squareland.controller;

import cz.cvut.fel.malyada1.squareland.model.Game;
import cz.cvut.fel.malyada1.squareland.model.map.MapEditor;
import javafx.scene.Scene;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;

import cz.cvut.fel.malyada1.squareland.view.GameView;
import cz.cvut.fel.malyada1.squareland.view.MenuView;
import cz.cvut.fel.malyada1.squareland.view.MapEditorView;

import java.util.logging.Logger;

import static cz.cvut.fel.malyada1.squareland.utils.Constants.*;

/**
 * The SceneController class manages the different scenes of the application, including the game, menu, and map editor.
 * It handles scene transitions and initializes the corresponding controllers and views.
 */
public class SceneController {
    private final Stage primaryStage;
    private final Scene scene;

    private final Game game;
    private final MapEditor editor;

    private GameController gameController;
    private MapEditorController mapEditorController;

    private GameView gameView;
    private MenuView menuView;
    private MapEditorView mapEditorView;

    private static final Logger logger = Logger.getLogger(SceneController.class.getName());

    /**
     * Constructor for the SceneController class.
     * @param primaryStage is the main stage of the application
     */
    public SceneController(Stage primaryStage) {
        this.primaryStage = primaryStage;
        this.scene = new Scene(new Pane(), WIDTH, HEIGHT);
        primaryStage.setScene(scene);
        primaryStage.setTitle("Simple game engine");
        primaryStage.setResizable(false);

        game = new Game();
        editor = new MapEditor();

        initializeViews();
        initializeControllers();
    }

    /**
     * Initializes the views for the menu, game, and map editor.
     */
    private void initializeViews() {
        menuView = new MenuView(WIDTH, HEIGHT);
        gameView = new GameView(WIDTH, HEIGHT, game);
        mapEditorView = new MapEditorView(WIDTH, HEIGHT, editor);
        logger.info("Views initialized");
    }

    /**
     * Initializes the controllers for the menu, game, and map editor.
     */
    private void initializeControllers() {
        new MenuController(menuView, this);
        gameController = new GameController(gameView, this);
        mapEditorController = new MapEditorController(mapEditorView, this);
        logger.info("Controllers initialized");
    }

    /**
     * Choose a map file for the game.
     * This method opens a file chooser dialog to select a map file.
     */
    public void chooseMapFile(){
        game.chooseMapFile();
        logger.info("Map file chosen");
    }

    /**
     * Show the menu scene.
     * This method stops the game loop if it is running and sets the menu view as the root of the scene.
     */
    public void showMenu() {
        if(gameController != null) {
            gameController.stopGameLoop();
        }
        scene.setRoot(menuView.getRoot());
        primaryStage.setTitle("Square Land - Menu");
        logger.info("Switched to menu scene");
    }

    /**
     * Show the game scene.
     * This method starts the game loop and sets the game view as the root of the scene.
     */
    public void startGame() {
        scene.setRoot(gameView.getRoot());
        primaryStage.setTitle("Square Land - Game");
        gameController.startGame();
        logger.info("Switched to game scene");
    }

    /**
     * Show the map editor scene.
     * This method sets the map editor view as the root of the scene and starts the map editor.
     */
    public void startEditor() {
        scene.setRoot(mapEditorView.getRoot());
        primaryStage.setTitle("Square Land - Map Editor");
        mapEditorController.startEditor();
        logger.info("Switched to map editor scene");
    }

   /**
     * Exit the game.
     */
    public void exitGame() {
        primaryStage.close();
        game.stopStopwatch();
        logger.info("Game exited");
    }

    /**
     * Get the primary stage of the application.
     * @return the primary stage
     */
    public Scene getScene() {
        return scene;
    }

    public Game getGame() {
        return game;
    }

    public MapEditor getMapEditor() {
        return editor;
    }
}
