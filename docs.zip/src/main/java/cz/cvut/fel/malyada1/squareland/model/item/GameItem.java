package cz.cvut.fel.malyada1.squareland.model.item;

/**
 * The GameItem class is an abstract representation of a game item.
 * It contains properties for the item's position and dimensions.
 */
public abstract class GameItem {
    private double x;
    private double y;
    private int width;
    private int height;

    /**
     * Constructor for the GameItem class.
     *
     * @param x      The x-coordinate of the item.
     * @param y      The y-coordinate of the item.
     * @param width  The width of the item.
     * @param height The height of the item.
     */
    public GameItem(double x, double y, int width, int height) {
        this.x = x;
        this.y = y;
        this.width = width;
        this.height = height;
    }

    public double getX() {
        return x;
    }

    public void setX(double x) {
        this.x = x;
    }

    public double getY() {
        return y;
    }

    public void setY(double y) {
        this.y = y;
    }

    public int getWidth() {
        return width;
    }

    public void setWidth(int width) {
        this.width = width;
    }

    public int getHeight() {
        return height;
    }

    public void setHeight(int height) {
        this.height = height;
    }
}
