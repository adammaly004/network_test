package cz.cvut.fel.malyada1.squareland.utils;

import cz.cvut.fel.malyada1.squareland.model.item.AmmunitionPack;
import cz.cvut.fel.malyada1.squareland.model.projectile.FireBall;
import cz.cvut.fel.malyada1.squareland.model.item.GameItem;
import cz.cvut.fel.malyada1.squareland.model.item.Heal;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import static cz.cvut.fel.malyada1.squareland.utils.Constants.TILE_SIZE;

/**
 * The ItemSpawner class is responsible for spawning items in the game.
 * It uses a map to determine valid tile positions for item placement.
 */
public class ItemSpawner {
    private static final List<int[]> validTiles = new ArrayList<>();

    /**
     * Constructor for the ItemSpawner class.
     * @param map the map to set
     */
    public ItemSpawner(int[][] map) {
        setValidTiles(map);
    }

    /**
     * Sets the map and updates the valid tiles.
     * @param map the map to set
     */
    public void setMap(int[][] map) {
        validTiles.clear();
        setValidTiles(map);
    }

    /**
     * Sets the valid tiles based on the map.
     * @param map the map to set
     */
    private void setValidTiles(int[][] map) {
        for (int row = 0; row < map.length; row++) {
            for (int col = 0; col < map[row].length; col++) {
                if (map[row][col] == 0) { // Assuming 0 represents a valid tile
                    validTiles.add(new int[]{row, col});
                }
            }
        }
    }

    /**
     * Spawns an item (AmmunitionPack or Heal) at a random valid tile.
     * @return a Rectangle representing the spawned item, or null if no valid tiles are available.
     */
    public GameItem spawnItems() {
        if (!validTiles.isEmpty()) {
            Random random = new Random();
            int[] selectedTile = validTiles.get(random.nextInt(validTiles.size()));

            // Calculate the position for the AmmunitionPack
            double x = selectedTile[1] * TILE_SIZE + TILE_SIZE / 2.0 - 5; // Centered on the tile
            double y = selectedTile[0] * TILE_SIZE + TILE_SIZE / 2.0 - 5;

            if (random.nextBoolean()) {
                return new AmmunitionPack(x, y);
            }
            else {
                return new Heal(x, y);
            }
        }
        return null;
    }

    /**
     * Spawns a FireBall at a random valid tile.
     * @return a FireBall object representing the spawned fireball.
     */
    public FireBall spawnFireBall() {
        Random random = new Random();
        int index = random.nextInt(validTiles.size());
        int[] selectedTile = validTiles.get(index);

        double x = selectedTile[1] * TILE_SIZE + TILE_SIZE / 2.0 - 5;
        double y = selectedTile[0] * TILE_SIZE + TILE_SIZE / 2.0 - 5;

        return new FireBall(x, y);
    }
}
