package cz.cvut.fel.malyada1.squareland.view;

import cz.cvut.fel.malyada1.squareland.model.map.MapEditor;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.layout.Pane;

import javafx.scene.shape.Rectangle;

import static cz.cvut.fel.malyada1.squareland.utils.Constants.TILE_SIZE;

/**
 * The MapEditorView class is responsible for creating the graphical user interface (GUI)
 * for the map editor in the game. It provides methods to display the map, save button,
 * and text field for entering the file name.
 */
public class MapEditorView {
    private final Pane root;
    private final Button saveButton;
    private final TextField textField;

    private final MapEditor editor;

    /**
     * Constructor for the MapEditorView class.
     * @param width is the width of the view
     * @param height is the height of the view
     */
    public MapEditorView(int width, int height, MapEditor editor) {
        root = new Pane();
        root.setPrefSize(width, height);
        root.setStyle("-fx-background-color: rgba(0,0,0,0.5);");

        saveButton = new Button("Save Map");
        saveButton.setPrefSize(100, 50);

        textField = new TextField("newMap");
        textField.setPromptText("Enter file name");
        textField.setPrefSize(100, 50);
        textField.setLayoutX(100);


        this.editor = editor;
        //root.getChildren().add(saveButton);
    }

    /**
     * Draws the map on the screen by creating rectangles for each tile.
     */
    public void drawMap() {
        int[][] mapArray = editor.getMap().getMapArray();
        for (int i = 0; i < mapArray.length; i++) {
            for (int j = 0; j < mapArray[i].length; j++) {
                Rectangle tile = new Rectangle(j * TILE_SIZE, i * TILE_SIZE, TILE_SIZE, TILE_SIZE);
                editor.getMap().setColors(i, j, tile);
                root.getChildren().add(tile);
            }
        }
    }

    /**
     * Draws the menu on the screen by adding the save button and text field.
     */
    public void drawMenu(){
        root.getChildren().addAll(saveButton, textField);
    }

    /**
     * Updates the tile in the map based on the row and column
     * @param row is the row of the tile
     * @param col is the column of the tile
     */
    public void updateTile(int row, int col) {
        int[][] mapArray = editor.getMap().getMapArray();
        int tileIndex = row * mapArray[0].length + col;
        Rectangle existingTile = (Rectangle) root.getChildren().get(tileIndex);
        editor.getMap().setColors(row, col, existingTile);
    }

    /**
     * Getter for the root pane
     * @return the root pane
     */
    public Pane getRoot() {
        return root;
    }

    /**
     * Getter for the save button
     * @return the save button
     */
    public Button getSaveButton() {
        return saveButton;
    }

    /**
     * Getter for the text field
     * @return the text field
     */
    public TextField getTextField() {
        return textField;
    }
}
