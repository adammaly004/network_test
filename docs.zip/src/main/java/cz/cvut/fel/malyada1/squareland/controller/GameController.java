package cz.cvut.fel.malyada1.squareland.controller;

import javafx.animation.AnimationTimer;
import javafx.scene.input.KeyCode;
import cz.cvut.fel.malyada1.squareland.model.Game;
import cz.cvut.fel.malyada1.squareland.view.GameView;

import java.util.HashSet;
import java.util.Set;
import java.util.logging.Logger;

import static cz.cvut.fel.malyada1.squareland.utils.LoggerConfig.isLoggingEnabled;
import static cz.cvut.fel.malyada1.squareland.utils.LoggerConfig.toggleLogging;

/**
 * The GameController class manages the game logic and interactions between the model and view.
 * It handles player input, game state updates, and rendering of game elements.
 */
public class GameController {
    private final Game model;
    private final GameView view;
    private final Set<KeyCode> keyPress;
    private final SceneController sceneController;
    private AnimationTimer gameLoop;


    // Player controllers
    private final PlayerController player1Controller;
    private final PlayerController player2Controller;

    private static final Logger logger = Logger.getLogger(GameController.class.getName());

    /**
     *
     * @param view is the view
     * @param sceneController is the scene controller
     */
    public GameController(GameView view, SceneController sceneController) {
        model = sceneController.getGame();

        player1Controller = new PlayerController(model.getPlayer1());
        player2Controller = new PlayerController(model.getPlayer2());

        this.view = view;
        this.sceneController = sceneController;
        keyPress = new HashSet<>();

        setKeyHandlers();

        logger.info("GameController initialized");
    }

    /**
     * Start the game loop and initialize the game state
     */
    public void startGame() {
        model.startStopwatch();
        gameLoop = new AnimationTimer() {
            @Override
            public void handle(long now) {
                update();
            }
        };
        gameLoop.start();
        logger.info("Game loop started");
    }

    /**
     * Set key handlers for the game scene
     */
    private void setKeyHandlers(){
        sceneController.getScene().setOnKeyPressed(e -> handleKeyPress(e.getCode()));
        sceneController.getScene().setOnKeyReleased(e -> handleKeyRelease(e.getCode()));
        logger.fine("Key handlers set");
    }

    /**
     * Handle key press events
     * @param code is the key code
     */
    public void handleKeyPress(KeyCode code) {
        // Pause and resume the game
        if(code == KeyCode.P){
            if(model.getIsPaused()){
                resumeGame();
            } else {
                pauseGame();
            }
        }
        // Restart the game
        if(code == KeyCode.R){
            restartGame();
            model.startStopwatch();
        }
        // Exit the game and show the menu
        if(code == KeyCode.ESCAPE){
            restartGame();
            sceneController.showMenu();
        }
        // Start or stop logging
        if(code == KeyCode.CONTROL){
            toggleLogging();
            logger.info("Logging toggled. Enabled: " + isLoggingEnabled());
        }
        keyPress.add(code);
        logger.finer("Key pressed: " + code);
    }

    /**
     * Handle key release events
     * @param code is the key code
     */
    private void handleKeyRelease(KeyCode code) {
        keyPress.remove(code);
        logger.finer("Key released: " + code);
    }

    /**
     * Update the game state
     */
    private void update() {
        if(!model.getIsPaused() && !model.isGameOver()){
            player1Controller.handleKeyPress(keyPress);
            player2Controller.handleKeyPress(keyPress);
            model.update();
        }

        view.update();
        logger.finer("Game updated");
    }

    /**
     * Pause the game
     */
    public void pauseGame(){
        model.setIsPaused(true);
        model.stopStopwatch();
        logger.info("Game paused");
    }

    /**
     * Resume the game
     */
    public void resumeGame(){
        model.setIsPaused(false);
        model.startStopwatch();
        logger.info("Game resumed");
    }


    /**
     * Restart the game by resetting the model
     */
    public void restartGame(){
        model.reset();
        model.resetStopwatch();
        logger.info("Game model reset");
    }

    /**
     * Exit the game, stopping the game loop
     */
    public void stopGameLoop(){
        if(gameLoop != null){
            gameLoop.stop();
            logger.info("Game loop stopped");
        }
    }
}

