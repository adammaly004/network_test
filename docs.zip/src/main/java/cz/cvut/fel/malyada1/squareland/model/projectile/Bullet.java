package cz.cvut.fel.malyada1.squareland.model.projectile;

/**
 * The Bullet class represents a bullet in the game.
 * It extends the Circle class for graphical representation and contains
 * information about its speed and damage.
 */
public class Bullet extends GameCircle {
    private final double dx;
    private final double dy;
    private final double speed;
    private final int damage;

    /**
     * Constructor for the Bullet class.
     *
     * @param x      The x-coordinate of the bullet.
     * @param y      The y-coordinate of the bullet.
     * @param dx     The x-direction of the bullet's movement.
     * @param dy     The y-direction of the bullet's movement.
     * @param speed  The speed of the bullet.
     * @param damage The damage dealt by the bullet.
     */
    public Bullet(double x, double y, double dx, double dy, double speed, int damage) {
        super(x, y, 3); // Set the radius of the bullet
        this.dx = dx;
        this.dy = dy;
        this.speed = speed;
        this.damage = damage;
    }

    /**
     * Moves the bullet in the direction specified by dx and dy.
     */
    public void move() {
        setCenterX(getCenterX() + dx * speed);
        setCenterY(getCenterY() + dy * speed);
    }

    public int getDamage() {
        return damage;
    }

    public double getDx() {
        return dx;
    }
    public double getDy() {
        return dy;
    }

}