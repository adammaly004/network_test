package cz.cvut.fel.malyada1.squareland.utils;

import java.util.Random;

import static cz.cvut.fel.malyada1.squareland.utils.Constants.*;


/**
 * The CreateArray class is responsible for generating a 2D array representing a map.
 * It provides methods to create a map with specific patterns and to create a blank map.
 * Map is currently not used in the game. It was used for testing purposes and quick generation of maps.
 */
public class CreateArray {
    static Random random = new Random();

    static int rows = HEIGHT / TILE_SIZE;
    static int cols = WIDTH / TILE_SIZE;

    /**
     * Creates a map with specific patterns and random values (0, 1, 2).
     * The map is generated based on the specified rows and columns.
     * @return A 2D array representing the map.
     */
    public static int[][] createMap(){
        int[][] mapArray = new int[rows][cols];
        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < cols; j++) {
                if (i == 0 || i == rows - 1 || j == 0 || j == cols - 1) {
                    mapArray[i][j] = 0; // Border
                } else if (i % 2 == 0 && j % 2 == 0) {
                    mapArray[i][j] = random.nextInt(5); // Some pattern
                } else {
                    mapArray[i][j] = random.nextInt(5); // Default
                }
            }
        }

        return mapArray;
    }

    /**
     * Creates a blank map with all values set to 0.
     * The map is generated based on the specified rows and columns.
     * @return A 2D array representing the blank map.
     */
    public static int[][] crateBlankMap(){
        int[][] mapArray = new int[rows][cols];
        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < cols; j++) {
                mapArray[i][j] = 0;
            }
        }
        return mapArray;
    }
}
