package cz.cvut.fel.malyada1.squareland.utils;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

/**
 * The MapSaver class is responsible for saving the map to a file.
 * It writes the map dimensions and the tile values to the specified file path.
 */
public class MapSaver {

    /**
     * The saveMap method saves the map to a file.
     * The first line of the file contains the number of rows, the second line contains the number of columns,
     * and the later lines contain the tile values.
     * @param map the 2D array representing the map
     * @param filePath the path to the file where the map will be saved
     * @throws IOException if an error occurs while writing to the file
     */

    public static void saveMap(int[][] map, String filePath) throws IOException {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(filePath))) {
            writer.write(map.length + "\n");
            writer.write(map[0].length + "\n");
            for (int[] row : map) {
                for (int tile : row) {
                    writer.write(tile + " ");
                }
                writer.write("\n");
            }
        }
    }
}