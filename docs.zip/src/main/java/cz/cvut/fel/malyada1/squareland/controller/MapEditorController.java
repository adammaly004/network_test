package cz.cvut.fel.malyada1.squareland.controller;

import javafx.scene.control.Button;
import javafx.scene.input.MouseButton;
import javafx.scene.input.MouseEvent;

import cz.cvut.fel.malyada1.squareland.model.map.MapEditor;
import cz.cvut.fel.malyada1.squareland.utils.MapSaver;
import cz.cvut.fel.malyada1.squareland.view.MapEditorView;

import java.io.IOException;

import static cz.cvut.fel.malyada1.squareland.utils.Constants.*;

/**
 * The MapEditorController class handles the interactions between the MapEditor model and the MapEditorView.
 * It manages mouse events for tile editing and saving the map to a file.
 */
public class MapEditorController {
    private final MapEditor model;
    private final MapEditorView view;
    private final SceneController sceneController;
    private boolean isMousePressed;
    private int lastRow;
    private int lastCol;

    /**
     * Constructor for the MapEditorController class.
     * @param view is the MapEditorView instance
     * @param sceneController the SceneController instance
     */
    public MapEditorController(MapEditorView view, SceneController sceneController) {
        this.sceneController = sceneController;
        this.view = view;
        this.isMousePressed = false;
        lastRow = -1;
        lastCol = -1;

        model = sceneController.getMapEditor();

        setMouseHandlers();
        setSaveButtonHandler();
    }

    /**
     * Starts the map editor by drawing the initial map and menu.
     */
    public void startEditor() {
        view.getRoot().getChildren().clear();
        view.drawMap();
        view.drawMenu();
    }

    /**
     * Sets up mouse event handlers for tile editing.
     */
    private void setMouseHandlers() {
        view.getRoot().setOnMousePressed(this::handleMousePress);
        view.getRoot().setOnMouseReleased(this::handleMouseRelease);
        view.getRoot().setOnMouseDragged(this::handleMouseDrag);
    }

    /**
     * Handles mouse press events for tile editing.
     * @param event the mouse event
     */
    private void handleMousePress(MouseEvent event) {
        isMousePressed = true;
        handleMouseEvent(event);
    }

    /**
     * Handles mouse release events for tile editing.
     * @param event the mouse event
     */
    private void handleMouseRelease(MouseEvent event) {
        isMousePressed = false;
        lastRow = -1;
        lastCol = -1;

    }

    /**
     * Handles mouse drag events for tile editing.
     * @param event the mouse event
     */
    private void handleMouseDrag(MouseEvent event) {
        if (isMousePressed) {
            handleMouseEvent(event);
        }
    }

    /**
     * Handles mouse events for tile editing
     * @param event the mouse event
     */
    private void handleMouseEvent(MouseEvent event) {
        double x = event.getX();
        double y = event.getY();

        // Check if the mouse is within the bounds of the map
        if (x > 0 && x < WIDTH && y > 0 && y < HEIGHT) {
            int row = (int) (y / TILE_SIZE);
            int col = (int) (x / TILE_SIZE);

            // Do not allow editing last row and column
            if (lastRow != row || lastCol != col) {
                if(event.getButton() == MouseButton.PRIMARY) {
                    model.getMap().incrementTile(row, col);
                } else if(event.getButton() == MouseButton.SECONDARY) {
                    model.getMap().setTile(row, col, 0);
                }
                view.updateTile(row, col);
                lastRow = row;
                lastCol = col;
            }
        }

    }

    /**
     * Sets up the save button handler to save the map to a file.
     */
    private void setSaveButtonHandler() {
        Button saveButton = view.getSaveButton();
        saveButton.setOnAction(_ -> {
            try {
                String filename = view.getTextField().getText();
                MapSaver.saveMap(model.getMap().getMapArray(), MAP_PATH + filename + ".txt");
            } catch (IOException ex) {
                System.out.println(ex.getMessage());
            }
        });
    }
}