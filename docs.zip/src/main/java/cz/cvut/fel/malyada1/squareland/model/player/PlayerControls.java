package cz.cvut.fel.malyada1.squareland.model.player;

import javafx.scene.input.KeyCode;
/**
 * The PlayerControls class represents the controls for a player in the game.
 * It contains the key bindings for moving up, down, left, right, and shooting.
 */
public record PlayerControls(KeyCode up, KeyCode down, KeyCode left, KeyCode right, KeyCode shoot) {
}