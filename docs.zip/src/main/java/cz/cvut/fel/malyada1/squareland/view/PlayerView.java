package cz.cvut.fel.malyada1.squareland.view;

import cz.cvut.fel.malyada1.squareland.model.player.PlayerModel;
import javafx.scene.paint.Color;
import javafx.scene.shape.Line;
import javafx.scene.shape.Rectangle;

/**
 * The PlayerView class represents the visual representation of a player in the game.
 * It extends the Rectangle class to create a rectangle shape for the player.
 */
public class PlayerView extends Rectangle {
    PlayerModel playerModel;
    private final Line directionMarker;

    /**
     * Constructor for the PlayerView class.
     *
     * @param playerModel The model representing the player's data and state.
     */
    public PlayerView(PlayerModel playerModel) {
        super(playerModel.getX(), playerModel.getY(), playerModel.getWidth(), playerModel.getHeight());
        this.playerModel = playerModel;
        setFill(playerModel.getColor());

        // Create a line to represent the direction marker
        directionMarker = new Line();
        directionMarker.setStroke(Color.BLACK);
        directionMarker.setStrokeWidth(5);
        updateDirectionMarker();
    }

    /**
     * Updates the position and appearance of the player view based on the player's model.
     * This method should be called to refresh the visual representation of the player.
     */
    public void update() {
        setX(playerModel.getX());
        setY(playerModel.getY());
        setFill(playerModel.getColor());
        updateDirectionMarker();
    }

    private void updateDirectionMarker() {
        double centerX = getX() + getWidth() / 2;
        double centerY = getY() + getHeight() / 2;

        directionMarker.setStartX(centerX);
        directionMarker.setStartY(centerY);

        // Set the end point of the line based on the player's direction
        switch (playerModel.getDirection()) {
            case 0 -> { // Up
                directionMarker.setEndX(centerX);
                directionMarker.setEndY(centerY - 15);
            }
            case 90 -> { // Right
                directionMarker.setEndX(centerX + 15);
                directionMarker.setEndY(centerY);
            }
            case 180 -> { // Down
                directionMarker.setEndX(centerX);
                directionMarker.setEndY(centerY + 15);
            }
            case 270 -> { // Left
                directionMarker.setEndX(centerX - 15);
                directionMarker.setEndY(centerY);
            }
        }
    }

    public Line getDirectionMarker() {
        return directionMarker;
    }
}