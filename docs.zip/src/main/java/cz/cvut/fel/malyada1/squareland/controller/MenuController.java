package cz.cvut.fel.malyada1.squareland.controller;

import cz.cvut.fel.malyada1.squareland.utils.LoggerConfig;
import cz.cvut.fel.malyada1.squareland.view.MenuView;


/**
 * The MenuController class handles the interactions between the MenuView and the SceneController.
 * It manages button actions for starting the game, exiting, and opening the map editor.
 */
public class MenuController {

    /**
     * Constructor for the MenuController class.
     * @param view is the MenuView instance
     * @param screenController is SceneController instance
     */
    public MenuController(MenuView view, SceneController screenController) {

        view.getStartButton().setOnAction(_ -> screenController.startGame());
        view.getExitButton().setOnAction(_ -> screenController.exitGame());
        view.getEditorButton().setOnAction(_-> screenController.startEditor());
        view.getChooseFileButton().setOnAction(_ -> screenController.chooseMapFile());

        view.getLoggerCheckBox().setSelected(LoggerConfig.isLoggingEnabled());
        view.getLoggerCheckBox().setOnAction(_ -> {
            LoggerConfig.toggleLogging();
            view.getLoggerCheckBox().setSelected(LoggerConfig.isLoggingEnabled());
        });

    }
}