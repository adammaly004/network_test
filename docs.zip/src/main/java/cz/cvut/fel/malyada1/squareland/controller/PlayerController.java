package cz.cvut.fel.malyada1.squareland.controller;

import cz.cvut.fel.malyada1.squareland.model.player.PlayerControls;
import cz.cvut.fel.malyada1.squareland.model.player.PlayerModel;
import javafx.scene.input.KeyCode;

import java.util.Set;

/**
 * The PlayerController class handles player input and movement.
 * It processes key presses and updates the player's position and actions accordingly.
 */
public class PlayerController {
    private final PlayerModel playerModel;
    private final PlayerControls playerKeys;

    private int movementTimer = 0;

    /**
     * Constructor for the PlayerController class.
     *
     * @param playerModel The PlayerModel instance representing the player.
     */
    public PlayerController(PlayerModel playerModel) {
        this.playerModel = playerModel;
        this.playerKeys = playerModel.getPlayerControls();
    }

    /**
     * Handles key press events for player movement and actions.
     *
     * @param keys A set of pressed keys.
     */
    public void handleKeyPress(Set<KeyCode> keys) {
        if (movementTimer > 10 && playerModel.getHealth() > 0) {
            for (KeyCode key : keys) {
                if (key == playerKeys.up() || key == playerKeys.down() || key == playerKeys.left() || key == playerKeys.right() || key == playerKeys.shoot()) {
                    movementTimer = 0;
                }
                if (key == playerKeys.up()) {
                    playerModel.move(0, -1);
                    break;
                } else if (key == playerKeys.down()) {
                    playerModel.move( 0, 1);
                    break;
                } else if (key == playerKeys.left()) {
                    playerModel.move( -1, 0);
                    break;
                } else if (key == playerKeys.right()) {
                    playerModel.move( 1, 0);
                    break;
                }if (key == playerKeys.shoot()) {
                    playerModel.shoot();
                }
            }
        }
        movementTimer++;
    }
}
