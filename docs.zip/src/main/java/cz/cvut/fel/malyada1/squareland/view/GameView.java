package cz.cvut.fel.malyada1.squareland.view;

import cz.cvut.fel.malyada1.squareland.model.item.AmmunitionPack;
import cz.cvut.fel.malyada1.squareland.model.item.GameItem;
import cz.cvut.fel.malyada1.squareland.model.item.Heal;
import cz.cvut.fel.malyada1.squareland.model.projectile.FireBall;
import cz.cvut.fel.malyada1.squareland.model.projectile.GameCircle;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.scene.text.Text;
import javafx.scene.shape.Rectangle;

import cz.cvut.fel.malyada1.squareland.model.*;

import static cz.cvut.fel.malyada1.squareland.utils.Constants.*;

/**
 * The GameView class is responsible for rendering the game elements on the screen.
 * It provides methods to draw the map, players, bullets, items, and text.
 */
public class GameView {
    private final Pane root;
    private final Game game;
    private final PlayerView player1View;
    private final PlayerView player2View;

    private final Text player1Text;
    private final Text player2Text;
    private final Text infoTextPlayer1;
    private final Text infoTextPlayer2;

    private final Text gameOverText;
    private final Text pauseText;
    private final Text stopWatchText;

    /**
     * Constructor for the GameView class.
     * @param width The width of the game window.
     * @param height The height of the game window.
     * @param game The game object that contains the game logic and state.
     */
    public GameView(int width, int height, Game game) {
        root = new Pane();
        root.setPrefSize(width, height);
        root.setStyle("-fx-background-color: black;");
        this.game = game;

        player1View = new PlayerView(game.getPlayer1());
        player2View = new PlayerView(game.getPlayer2());

        // Text
        player1Text = new Text(10, 20, "Player 1");
        player2Text = new Text(WIDTH-50, 20, "Player 2");
        player1Text.setFill(Color.WHITE);
        player2Text.setFill(Color.WHITE);

        infoTextPlayer1 = new Text(10, HEIGHT-50, "Info");
        infoTextPlayer2 = new Text(WIDTH-150, HEIGHT-50, "Info2");
        infoTextPlayer1.setFill(Color.WHITE);
        infoTextPlayer2.setFill(Color.WHITE);

        gameOverText = new Text((double) WIDTH/2, (double) HEIGHT /2, "Game Over");
        gameOverText.setFont(javafx.scene.text.Font.font("Arial", 30));
        gameOverText.setFill(Color.RED);
        gameOverText.setVisible(false);

        pauseText = new Text((double) WIDTH/2, (double) HEIGHT/2, "Paused");
        pauseText.setX((WIDTH - pauseText.getLayoutBounds().getWidth()) / 2);
        pauseText.setY((HEIGHT - pauseText.getLayoutBounds().getHeight()) / 2);
        pauseText.setFont(javafx.scene.text.Font.font("Arial", 30));
        pauseText.setFill(Color.RED);
        pauseText.setVisible(false);

        stopWatchText = new Text((double) WIDTH/2, 40,  game.getStopWatchTime());
        stopWatchText.setX((WIDTH - stopWatchText.getLayoutBounds().getWidth()) / 2);
        //stopWatchText.setY((HEIGHT - stopWatchText.getLayoutBounds().getHeight()) / 2);
        stopWatchText.setFont(javafx.scene.text.Font.font("Arial", 30));
        stopWatchText.setFill(Color.WHITE);
    }

    /**
     * Draws the map on the game view.
     */
    public void drawMap() {
        int[][] mapArray = game.getMap().getMapArray();
        for (int i = 0; i < mapArray.length; i++) {
            for (int j = 0; j < mapArray[i].length; j++) {
                Rectangle tile = new Rectangle(j * TILE_SIZE, i * TILE_SIZE, TILE_SIZE, TILE_SIZE);
                game.getMap().setColors(i, j, tile);
                root.getChildren().add(tile);
            }
        }
    }

    /**
     * Updates the player views to reflect their current state.
     */
    private void updatePlayers(){
        player1View.update();
        player2View.update();
    }

    /**
     * Updates the text information displayed on the game view.
     */
    private void updateStats(){
        player1Text.setText("Player 1:\nLives: " + game.getPlayer1().getHealth() +"\n" +
                "Ammo: " + game.getPlayer1().getAmmo() + "\n");
        player2Text.setText("Player 2:\nLives: " + game.getPlayer2().getHealth() +"\n" +
                "Ammo: " + game.getPlayer2().getAmmo() + "\n");

        infoTextPlayer1.setText(game.getPlayer1().getInfo());
        infoTextPlayer2.setText(game.getPlayer2().getInfo());

        stopWatchText.setText(game.getStopWatchTime());


    }

    /**
     * Updates the game view by refreshing the players, stats, and game state.
     */
    public void update(){
        this.updatePlayers();
        this.updateStats();

        pauseText.setVisible(game.getIsPaused());

        if(game.isGameOver()){
            gameOverText.setText("Game Over: player " + game.getWinner() + " wins!\n" +
                    "Press R to restart");
            gameOverText.setX((WIDTH - gameOverText.getLayoutBounds().getWidth()) / 2);
            gameOverText.setY((HEIGHT - gameOverText.getLayoutBounds().getHeight()) / 2);
            gameOverText.setVisible(true);
        }else {
            gameOverText.setVisible(false);
        }

        // Draw the updated game view
        this.draw();
    }

    /**
     * Draws the game view by clearing the root pane and adding all game elements.
     */
    public void draw(){
        root.getChildren().clear();

        drawMap();
        root.getChildren().addAll(player1Text, player2Text, infoTextPlayer1, infoTextPlayer2, gameOverText, pauseText, stopWatchText);

        drawItems();
        drawFireballs();

        root.getChildren().add(player1View);
        root.getChildren().add(player2View);

        drawBullets();

        root.getChildren().add(player1View.getDirectionMarker());
        root.getChildren().add(player2View.getDirectionMarker());
    }

    /**
     * Draws the items on the game view.
     */
    private void drawItems(){
        for(GameItem item : game.getItems()){
            Rectangle itemRect = new Rectangle();
            itemRect.setX(item.getX());
            itemRect.setY(item.getY());
            itemRect.setWidth(item.getWidth());
            itemRect.setHeight(item.getHeight());

            if(item instanceof Heal){
                itemRect.setFill(Color.DEEPPINK);
            }
            if(item instanceof AmmunitionPack){
                itemRect.setFill(Color.YELLOW);
            }
            root.getChildren().add(itemRect);
        }
    }

    /**
     * Draws the bullets on the game view.
     */
    private void drawBullets(){
        for(GameCircle circle : game.getPlayer1().getBullets()){
            Circle bullet = new Circle();
            bullet.setRadius(circle.getRadius());
            bullet.setCenterX(circle.getX());
            bullet.setCenterY(circle.getY());
            bullet.setFill(Color.YELLOW);
            root.getChildren().add(bullet);
        }
        for(GameCircle circle : game.getPlayer2().getBullets()){
            Circle bullet = new Circle();
            bullet.setRadius(circle.getRadius());
            bullet.setCenterX(circle.getX());
            bullet.setCenterY(circle.getY());
            bullet.setFill(Color.YELLOW);
            root.getChildren().add(bullet);
        }
    }

    /**
     * Draws the fireballs on the game view.
     */
    private void drawFireballs(){
        for(GameCircle circle : game.getFireBalls()){
            Circle fireBall = new Circle();
            FireBall f = (FireBall) circle;
            fireBall.setRadius(circle.getRadius());
            fireBall.setCenterX(circle.getX());
            fireBall.setCenterY(circle.getY());
            fireBall.setFill(f.getCurrentColor());
            root.getChildren().add(fireBall);
        }
    }

    /**
     * Returns the root pane of the game view.
     * @return The root pane.
     */
    public Pane getRoot() {
        return root;
    }
}