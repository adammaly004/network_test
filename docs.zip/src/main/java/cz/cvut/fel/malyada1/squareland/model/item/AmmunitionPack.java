package cz.cvut.fel.malyada1.squareland.model.item;

/**
 * The AmmunitionPack class represents an ammunition pack in the game.
 * It extends the Rectangle class for graphical representation and contains
 * information about the amount of ammo it adds to the player.
 */
public class AmmunitionPack extends GameItem
{
    private final int addedAmmo;
    /**
     * Constructor for the AmmunitionPack class.
     * @param x The x-coordinate of the ammunition pack.
     * @param y The y-coordinate of the ammunition pack.
     */
    public AmmunitionPack(double x, double y) {
        super(x, y, 10, 10);
        this.addedAmmo = 2;
    }
    /**
     * Returns the amount of ammo added by this ammunition pack.
     * @return The amount of ammo added.
     */
    public int getAddedAmmo() {
        return addedAmmo;
    }

}
