package cz.cvut.fel.malyada1.squareland.model.item;

/**
 * The Heal class represents a healing item in the game.
 * It extends the Rectangle class for graphical representation and contains
 * information about the amount of health it restores to the player.
 */
public class Heal extends GameItem {
    private final int healAmount;

    /**
     * Constructor for the Heal class.
     *
     * @param x The x-coordinate of the healed item.
     * @param y The y-coordinate of the healed item.
     */
    public Heal(double x, double y) {
        super(x, y, 10, 10);
        this.healAmount = 1;
    }
    /**
     * Returns the amount of health added by this healed item.
     *
     * @return The amount of health added.
     */
    public int getAddedLives() {
        return healAmount;
    }
}