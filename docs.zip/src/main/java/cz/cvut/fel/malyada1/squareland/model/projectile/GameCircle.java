package cz.cvut.fel.malyada1.squareland.model.projectile;

/**
 * The GameItem class is an abstract representation of a game item.
 * It contains properties for the item's position and dimensions.
 */
public abstract class GameCircle {
    private double x;
    private double y;
    private int radius;

    /**
     * Constructor for the GameCircle class.
     *
     * @param x      The x-coordinate of the circle.
     * @param y      The y-coordinate of the circle.
     * @param radius  The radius of the circle.
     */
    public GameCircle(double x, double y, int radius) {
        this.x = x;
        this.y = y;
        this.radius = radius;
    }

    public double getX() {
        return x;
    }

    public void setX(double x) {
        this.x = x;
    }

    public double getY() {
        return y;
    }

    public void setY(double y) {
        this.y = y;
    }

    public int getRadius() {
        return radius;
    }

    public void setRadius(int radius) {
        this.radius = radius;
    }

    public double getCenterX() {
        return x + radius;
    }
    public double getCenterY() {
        return y + radius;
    }
    public void setCenterX(double centerX) {
        this.x = centerX - radius;
    }
    public void setCenterY(double centerY) {
        this.y = centerY - radius;
    }
}
