package cz.cvut.fel.malyada1.squareland.model.projectile;

import javafx.scene.paint.Color;

/**
 * The FireBall class represents a fireball in the game.
 * It extends the Circle class for graphical representation and contains
 * information about its position, damage, and size.
 */
public class FireBall extends GameCircle {
    private int damage;
    private final int maxRadius;
    private final int maxDamage;
    private Color currentColor;
    private int timer = 0;

    /**
     * Constructor for the FireBall class.
     * @param x The x-coordinate of the fireball.
     * @param y The y-coordinate of the fireball.
     */
    public FireBall(double x, double y){
        super(x, y, 5);
        damage = 0;
        maxDamage = 1;
        maxRadius = 40;
        currentColor = Color.YELLOW;
    }

    /**
     * Initializes the fireball's growth and damage over time.
     * The fireball grows in size and its damage increases until it reaches its maximum size.
     */
    public void initFireBall() {
        timer++;
        if(timer % 5 == 0){
            if (getRadius() < maxRadius) {
                setRadius(getRadius() + 1);
                updateColor();
            } else {
                damage = maxDamage;
            }
        }
    }

    /**
     * Interpolates the color from yellow to red as the fireball grows.
     */
    private void updateColor() {
        double ratio = (double) getRadius() / maxRadius;  // from 0.0 to 1.0

        // Interpolate green component from 255 (yellow) to 0 (red)
        int green = (int) (255 * (1 - ratio));
        currentColor = Color.rgb(255, green, 0, 0.5);
    }

    public int getDamage() {
        return damage;
    }

    public Color getCurrentColor() {
        return currentColor;
    }
}
