package cz.cvut.fel.malyada1.squareland.model.player;

import cz.cvut.fel.malyada1.squareland.model.item.AmmunitionPack;
import cz.cvut.fel.malyada1.squareland.model.item.GameItem;
import cz.cvut.fel.malyada1.squareland.model.item.Heal;
import cz.cvut.fel.malyada1.squareland.model.projectile.Bullet;
import cz.cvut.fel.malyada1.squareland.model.projectile.FireBall;
import cz.cvut.fel.malyada1.squareland.model.projectile.GameCircle;
import cz.cvut.fel.malyada1.squareland.utils.Collisions;
import cz.cvut.fel.malyada1.squareland.utils.Constants;

import javafx.scene.input.KeyCode;
import javafx.scene.paint.Color;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import java.util.logging.Logger;

/**
 * The PlayerModel class represents a player in the game.
 * It contains the player's position, dimensions, health, ammo, and controls.
 * It also handles player movement, shooting, and collision detection with other game elements.
 */
public class PlayerModel {
    private double x;
    private double y;
    private final int width;
    private final int height;

    private int dx;
    private int dy;

    private double previousX;
    private double previousY;

    private int ammo;
    private int health;

    private final int speed;
    private final Color color;

    private final String name;
    private String info;

    private final List<GameCircle> bullets = new ArrayList<>();

    private final PlayerControls playerControls;
    private final Collisions collisions;

    private static final Logger logger = Logger.getLogger(PlayerModel.class.getName());

    /**
     * Constructor for the PlayerModel class.
     * @param x The x-coordinate of the player.
     * @param y The y-coordinate of the player.
     * @param width The width of the player.
     * @param height The height of the player.
     * @param name The name of the player.
     * @param color The color of the player.
     * @param collisions The collision detection object.
     */
    public PlayerModel(double x, double y, int width, int height, String name, Color color, Collisions collisions)  {
        this.x = x;
        this.y = y;
        this.dx = 1;
        this.dy = 0;

        this.previousX = x;
        this.previousY = y;

        this.width = width;
        this.height = height;
        this.ammo = 3;
        this.health = 5;
        this.speed = 20;
        this.name = name;
        this.color = color;
        this.collisions = collisions;

        // Initialize the player controls based on the player's name
        if(this.name.equals("player1")) {
            this.playerControls = new PlayerControls(KeyCode.W, KeyCode.S, KeyCode.A, KeyCode.D, KeyCode.F);
        } else {
            this.playerControls = new PlayerControls(KeyCode.UP, KeyCode.DOWN, KeyCode.LEFT, KeyCode.RIGHT, KeyCode.L);
        }

    }
    /**
     * Resets the player to its initial state.
     */
    public void reset(){
        if(this.name.equals("player1")) {
            this.x = 0;
            this.y = 0;
        }else{
            this.x = Constants.WIDTH - width;
            this.y = Constants.HEIGHT - height;
        }

        this.ammo = 3;
        this.health = 5;
        bullets.clear();
        logger.info(name + " was reset to default state.");
    }

    /**
     * Moves the player in the specified direction.
     * @param dx The change in x-coordinate.
     * @param dy The change in y-coordinate.
     */
    public void move(int dx, int dy) {
        this.previousX = x;
        this.previousY = y;

        this.dx = dx;
        this.dy = dy;
        this.x += dx * speed;
        this.y += dy * speed;

        logger.fine(name + " moved to position (" + x + ", " + y + ")");
    }

    /**
     * Shoots a bullet in the direction the player is facing.
     * If the player has ammo, a bullet is created and added to the bullet list.
     */
    public void shoot(){
        if (ammo > 0) {
            Bullet bullet = new Bullet(x + (double) width / 2, y + (double) (height / 2), dx, dy, 5, 1);
            bullets.add(bullet);
            ammo--;
            logger.info(name + " shot a bullet. Remaining ammo: " + ammo);
        }else {
            logger.warning(name + " tried to shoot but has no ammo left.");
        }
    }

    /**
     * Handles collision detection with circles
     * @param circles The list of circles to check for collisions with.
     */
    public void circleCollision(List<GameCircle> circles) {
        Iterator<GameCircle> iterator = circles.iterator();
        while (iterator.hasNext()) {
            GameCircle circle = iterator.next();
            if (circleIntersects(circle)) {
                if (circle instanceof Bullet b) {
                    health -= b.getDamage();
                    info = name + " collided with bullet";
                    logger.info(info + ". Health now: " + health);
                    iterator.remove();
                }
                if (circle instanceof FireBall f) {
                    health -= f.getDamage();
                    info = name + " collided with fireball";
                    logger.info(info + ". Health now: " + health);
                }

            }
        }
    }

    /**
     * Handles collision detection with rectangles
     * @param items The list of rectangles to check for collisions with.
     */
    public void rectangleCollision(List<GameItem> items) {
        Iterator<GameItem> iterator = items.iterator();
        while (iterator.hasNext()) {
            GameItem item = iterator.next();
            if (intersects(item)) {
                if (item instanceof AmmunitionPack ap) {
                    ammo += ap.getAddedAmmo();
                    info = name + " picked up ammo";
                    logger.info(info + ". Ammo now: " + ammo);
                } else if (item instanceof Heal h) {
                    health += h.getAddedLives();
                    info = name + " picked up health";
                    logger.info(info + ". Health now: " + health);
                }
                iterator.remove();
            }
        }
    }

    /**
     * Handles collision detection with the game borders.
     * If the player collides with a border, it resets the player's position to the previous position.
     */
    public void borderCollision(){
        if (x < 0 || x + width > Constants.WIDTH || y < 0 || y + height > Constants.HEIGHT) {
            setX(previousX);
            setY(previousY);
            info = name + " collided with border";
            logger.warning(info);
        }

    }

    /**
     * Handles collision detection with tiles.
     * If the player collides with a tile, it resets the player's position to the previous position.
     */
    public void tileCollision() {
        if (collisions.isCollidingWithTile(x, y, "player")) {
            setX(previousX);
            setY(previousY);
            info = name + " collided with tile";
            logger.warning(info);
        }
    }

    /**
     * Check if this player intersects with another rectangle.
     * @param item the rectangle to check intersection with.
     * @return true if the player intersects with the rectangle, false otherwise.
     */
    private boolean intersects(GameItem item) {
        return x < item.getX() + item.getWidth() &&
                x + width > item.getX() &&
                y < item.getY() + item.getHeight() &&
                y + height > item.getY();
    }

    /**
     * Check if this player intersects with another circle.
     * @param circle the circle to check intersection with.
     * @return true if the player intersects with the circle, false otherwise.
     */
    private boolean circleIntersects(GameCircle circle) {
        double circleDistanceX = Math.abs(circle.getX() - (x + width / 2.0));
        double circleDistanceY = Math.abs(circle.getY() - (y + height / 2.0));

        if (circleDistanceX > (width / 2.0 + circle.getRadius())) return false;
        if (circleDistanceY > (height / 2.0 + circle.getRadius())) return false;

        if (circleDistanceX <= (width / 2.0)) return true;
        if (circleDistanceY <= (height / 2.0)) return true;

        double cornerDistanceSq = Math.pow(circleDistanceX - width / 2.0, 2)
                + Math.pow(circleDistanceY - height / 2.0, 2);

        return cornerDistanceSq <= Math.pow(circle.getRadius(), 2);
    }

    public int getDirection() {
        if (dx == 1 && dy == 0) {
            return 90;
        } else if (dx == 0 && dy == 1) {
            return 180;
        } else if (dx == -1 && dy == 0) {
            return 270;
        } else if (dx == 0 && dy == -1) {
            return 0;
        }
        return 0;
    }

    public double getX() {
        return x;
    }

    public double getY() {
        return y;
    }

    public int getWidth() {
        return width;
    }
    public int getHeight() {
        return height;
    }

    public int getAmmo() {
        return ammo;
    }

    public int getHealth() {
        return health;
    }

    public int getSpeed() {
        return speed;
    }

    public List<GameCircle> getBullets() {
        return bullets;
    }

    public String getName() {
        return name;
    }
    public Color getColor() {
        return color;
    }
    public PlayerControls getPlayerControls() {
        return playerControls;
    }

    public void setX(double x) {
        this.x = x;
    }

    public void setY(double y) {
        this.y = y;
    }

    public void setAmmo(int ammo) {
        this.ammo = ammo;
    }

    public void setHealth(int health) {
        this.health = health;
    }

    public String getInfo() {
        return info;
    }

}
