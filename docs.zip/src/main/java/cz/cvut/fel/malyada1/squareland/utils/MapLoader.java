package cz.cvut.fel.malyada1.squareland.utils;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

/**
 * The MapLoader class is responsible for loading the map from a file.
 * It reads the map dimensions and the tile values from the file and returns a 2D array representing the map.
 */
public class MapLoader {
    /**
     * The loadMap method reads the map from a file and returns a 2D array representing the map.
     * The first line of the file contains the number of rows, the second line contains the number of columns,
     * and the later lines contain the tile values.
     * @param filePath the path to the map file
     * @return a 2D array representing the map
     */
    public static int[][] loadMap(String filePath) {
        try (BufferedReader reader = new BufferedReader(new FileReader(filePath))) {
            String line = reader.readLine();
            int rows = Integer.parseInt(line);
            int cols = Integer.parseInt(reader.readLine());
            int[][] map = new int[rows][cols];

            for (int i = 0; i < rows; i++) {
                line = reader.readLine();
                String[] tokens = line.split(" ");
                for (int j = 0; j < cols; j++) {
                    map[i][j] = Integer.parseInt(tokens[j]);
                }
            }
            return map;
        }
        catch (IOException | NumberFormatException | ArrayIndexOutOfBoundsException e) {
            System.err.println("Error while loading map from file: " + filePath);
            return null;
        }
    }
}