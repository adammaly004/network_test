package cz.cvut.fel.malyada1.squareland.model;

import cz.cvut.fel.malyada1.squareland.model.item.AmmunitionPack;
import cz.cvut.fel.malyada1.squareland.model.item.GameItem;
import cz.cvut.fel.malyada1.squareland.model.item.Heal;
import cz.cvut.fel.malyada1.squareland.model.player.PlayerModel;
import cz.cvut.fel.malyada1.squareland.model.projectile.Bullet;
import cz.cvut.fel.malyada1.squareland.model.projectile.FireBall;
import cz.cvut.fel.malyada1.squareland.model.projectile.GameCircle;
import cz.cvut.fel.malyada1.squareland.utils.Collisions;
import cz.cvut.fel.malyada1.squareland.utils.Constants;
import javafx.scene.paint.Color;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

public class PlayerModelTest {
    private PlayerModel playerModel;

    @BeforeEach
    public void setUp() {
        playerModel = new PlayerModel(0, 0, 10, 10, "player1", Color.BLUE, new Collisions());
    }

    @Test
    public void testMove() {
        playerModel.move(5, 5);
        assertEquals(5 * playerModel.getSpeed(), playerModel.getX());
        assertEquals(5 * playerModel.getSpeed(), playerModel.getY());
    }

    @Test
    void testShoot_createsBulletAndDecreasesAmmo() {
        Collisions collisions = Mockito.mock(Collisions.class);
        PlayerModel player = new PlayerModel(100, 100, 50, 50, "player1", Color.GREEN, collisions);

        int initialAmmo = player.getAmmo();
        player.move(1, 0); // Nastavíme směr doprava
        player.shoot();

        List<GameCircle> bullets = player.getBullets();
        assertEquals(initialAmmo - 1, player.getAmmo());
        assertEquals(1, bullets.size());

        GameCircle bullet = bullets.getFirst();
        assertInstanceOf(Bullet.class, bullet);
        assertEquals(1, ((Bullet) bullet).getDx());
        assertEquals(0, ((Bullet) bullet).getDy());
    }

    @Test
    void testRectangleCollision_picksUpHealAndAmmo() {
        Collisions collisions = Mockito.mock(Collisions.class);
        PlayerModel player = new PlayerModel(0, 0, 50, 50, "player1", Color.BLUE, collisions);

        Heal heal = Mockito.mock(Heal.class);
        Mockito.when(heal.getX()).thenReturn(0.0);
        Mockito.when(heal.getY()).thenReturn(0.0);
        Mockito.when(heal.getWidth()).thenReturn(30);
        Mockito.when(heal.getHeight()).thenReturn(30);
        Mockito.when(heal.getAddedLives()).thenReturn(2);

        AmmunitionPack ammoPack = Mockito.mock(AmmunitionPack.class);
        Mockito.when(ammoPack.getX()).thenReturn(0.0);
        Mockito.when(ammoPack.getY()).thenReturn(0.0);
        Mockito.when(ammoPack.getWidth()).thenReturn(30);
        Mockito.when(ammoPack.getHeight()).thenReturn(30);
        Mockito.when(ammoPack.getAddedAmmo()).thenReturn(4);

        int originalHealth = player.getHealth();
        int originalAmmo = player.getAmmo();

        List<GameItem> items = new ArrayList<>(List.of(heal, ammoPack));
        player.rectangleCollision(items);

        assertEquals(originalHealth + 2, player.getHealth());
        assertEquals(originalAmmo + 4, player.getAmmo());
        assertTrue(player.getInfo().contains("picked up"));
        assertTrue(items.isEmpty());
    }

    @Test
    void testCircleCollision_withFireball_damagesPlayerButDoesNotRemoveFireball() {
        Collisions collisions = Mockito.mock(Collisions.class);
        PlayerModel player = new PlayerModel(100, 100, 50, 50, "player1", Color.BLUE, collisions);

        FireBall fireBall = Mockito.mock(FireBall.class);
        Mockito.when(fireBall.getX()).thenReturn(110.0); // uvnitř hráče
        Mockito.when(fireBall.getY()).thenReturn(110.0);
        Mockito.when(fireBall.getRadius()).thenReturn(10);
        Mockito.when(fireBall.getDamage()).thenReturn(2);

        int originalHealth = player.getHealth();
        List<GameCircle> circles = new ArrayList<>();
        circles.add(fireBall);

        player.circleCollision(circles);

        // Fireball by měl způsobit poškození, ale neměl by být odstraněn
        assertEquals(originalHealth - 2, player.getHealth());
        assertTrue(player.getInfo().contains("collided with fireball"));
        assertEquals(1, circles.size(), "Fireball should remain in the list");
    }

    @Test
    void testTileCollision_whenColliding_resetsToPreviousPosition() {
        // Mock kolizní systém, který tvrdí, že kolize nastala
        Collisions collisions = Mockito.mock(Collisions.class);
        Mockito.when(collisions.isCollidingWithTile(Mockito.anyDouble(), Mockito.anyDouble(), Mockito.eq("player")))
                .thenReturn(true);

        PlayerModel player = new PlayerModel(100, 100, 50, 50, "player1", Color.PURPLE, collisions);

        // Nejprve se hráč někam posune — tím si nastavíme previousX/previousY
        player.move(1, 0);  // posune o `speed` doprava

        double prevX = player.getX(); // uložíme novou pozici
        double prevY = player.getY();

        // Simulujme, že se hráč zase posune, ale teď narazí na tile
        player.move(1, 0); // opět doprava
        double afterMoveX = player.getX();
        double afterMoveY = player.getY();

        assertNotEquals(prevX, afterMoveX); // ujistíme se, že se hráč fakt pohnul

        player.tileCollision();

        // Po kolizi se hráč musí vrátit na pozici před posledním pohybem
        assertEquals(prevX, player.getX(), 0.001);
        assertEquals(prevY, player.getY(), 0.001);
        assertTrue(player.getInfo().contains("collided with tile"));
    }
}
