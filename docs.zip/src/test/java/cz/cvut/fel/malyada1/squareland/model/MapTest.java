package cz.cvut.fel.malyada1.squareland.model;

public class MapTest {



}
