package cz.cvut.fel.malyada1.squareland.controller;


public class GameControllerTest {


}