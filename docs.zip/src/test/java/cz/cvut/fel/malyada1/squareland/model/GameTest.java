package cz.cvut.fel.malyada1.squareland.model;

import cz.cvut.fel.malyada1.squareland.model.item.GameItem;
import cz.cvut.fel.malyada1.squareland.model.item.Heal;
import cz.cvut.fel.malyada1.squareland.model.player.PlayerModel;
import cz.cvut.fel.malyada1.squareland.model.projectile.FireBall;
import cz.cvut.fel.malyada1.squareland.model.projectile.GameCircle;
import static cz.cvut.fel.malyada1.squareland.utils.Constants.*;

import javafx.application.Platform;
import javafx.scene.paint.Color;


import javafx.stage.FileChooser;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.testfx.util.WaitForAsyncUtils;

import java.io.File;
import java.util.List;
import java.util.concurrent.CountDownLatch;

import static org.junit.jupiter.api.Assertions.*;

class GameTest {

    private Game game;

    @BeforeAll
    static void initToolkit() throws Exception {
        if (!Platform.isFxApplicationThread()) {
            final CountDownLatch latch = new CountDownLatch(1);
            Platform.startup(latch::countDown);
            latch.await();
        }
    }

    @BeforeEach
    void setUp() {
        game = new Game();
    }

    @Test
    void testInitialPlayerState() {
        PlayerModel player1 = game.getPlayer1();
        PlayerModel player2 = game.getPlayer2();

        assertEquals(0, player1.getX());
        assertEquals(0, player1.getY());
        assertEquals(Color.AQUA, player1.getColor());

        assertEquals(WIDTH - TILE_SIZE, player2.getX());
        assertEquals(HEIGHT - TILE_SIZE, player2.getY());
        assertEquals(Color.BLUEVIOLET, player2.getColor());
    }

    @Test
    void testReset() {
        game.getPlayer1().setAmmo(0);
        game.getPlayer2().setHealth(0);
        game.getItems().add(new Heal(0, 0));
        game.getFireBalls().add(new FireBall(0, 0));

        game.reset();

        assertEquals(3, game.getPlayer1().getAmmo());
        assertEquals(5, game.getPlayer2().getHealth());
        assertTrue(game.getItems().isEmpty());
        assertTrue(game.getFireBalls().isEmpty());
    }

    @Test
    void testUpdateAddsFireballsAndItemsEventually() {
        for (int i = 0; i < 600; i++) {
            game.update();
        }

        List<GameCircle> fireballs = game.getFireBalls();
        List<GameItem> items = game.getItems();

        assertFalse(fireballs.isEmpty(), "Fireballs should be spawned after updates");
        assertFalse(items.isEmpty(), "Items should be spawned after updates");
    }

    @Test
    void testUpdateMovesBulletsAndDetectsBoundaries() {
        game.getPlayer1().shoot();  // This adds a bullet
        int initialCount = game.getPlayer1().getBullets().size();

        for (int i = 0; i < 1000; i++) {
            game.update();  // Eventually, the bullet will hit a wall or go out of bounds
        }

        int finalCount = game.getPlayer1().getBullets().size();
        assertTrue(finalCount < initialCount, "Bullet should be removed after hitting boundary or tile");
    }

    @Test
    void testChooseMapFile_ValidFile() {
        Platform.runLater(() -> {
            FileChooser fileChooser = new FileChooser();
            File validFile = new File("MAP.txt");
            fileChooser.setInitialDirectory(validFile.getParentFile());


            game.chooseMapFile();

            assertEquals("MAP.txt", game.getFilePath(), "Path to the map file should be set correctly.");
            assertNotNull(game.getMap().getMapArray(), "Map array should not be null.");
        });
        WaitForAsyncUtils.waitForFxEvents();
    }
}

