# Herní engine - Square Land

## Shrnutí

Cílem projektu je vytvořit herní engine pro <b>2D střílečku ve stylu 1v1</b>, kde se dva hráči
utkají v dynamickém souboji na život a na smrt. Hra nabídne interaktivní prvky, jako jsou padající
bomby a překážky (např. zdi či vodní plochy), které ovlivní strategii i pohyb hráčů. Pohled na herní
pole bude ze shora.
Každá postava bude disponovat střelnou zbraní s omezeným počtem nábojů, které lze doplňovat
sbíráním náhodně se objevujících nábojnic. Stejným způsobem si hráči mohou obnovit životy
díky regeneracím rozmístěným po mapě. Pohyb postav bude probíhat po 2D mřížce ve čtyřech
směrech, což zajistí přesnost herních mechanik.
Klíčovou součástí projektu je vývoj enginu, který umožní snadnou tvorbu a správu herních map.
Podporuje načítání levelů z externích souborů a obsahuje vestavěný editor, díky němuž lze
intuitivně vytvářet a upravovat herní prostředí bez nutnosti ruční editace souborů. Tento přístup
zajistí flexibilitu a jednoduchost při navrhování nových map a herních scénářů.


